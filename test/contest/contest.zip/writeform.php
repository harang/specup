<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>게시물 작성 예제 폼</title>
</head>
<body>
	<form enctype="multipart/form-data" name="form" method="post" action="dywriteload.php">
		<table>
		<tr>
			<td>아이디:</td>
			<td><input type="text" name="userid" /></td>
		</tr>
		<tr>
			<td>제목:</td>
			<td><input type="text" name="title" /></td>
		</tr>
		<tr>
			<td>내용:</td>
			<td><textarea name="content"></textarea></td>
		</tr>
		<tr>
			<td>이미지:</td>
			<td><input type="file" name="imageform" /></td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="submit" value="전송" />
			</td>
		</tr>
		</table>
	</form>
</body>
</html>
