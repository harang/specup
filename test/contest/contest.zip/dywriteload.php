<?
/**
 * Copyright 2010-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * This file is licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License. A copy of
 * the License is located at
 *
 * http://aws.amazon.com/apache2.0/
 *
 * This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
*/

require '/var/www/html/vendor/autoload.php';

date_default_timezone_set('UTC');

use Aws\DynamoDb\Exception\DynamoDbException;
use Aws\DynamoDb\Marshaler;

$sdk = new Aws\Sdk([
    'region'   => 'ap-northeast-2',
    'version'  => 'latest'
]);

$dynamodb = $sdk->createDynamoDb();
$marshaler = new Marshaler();

$tableName = 'contest';

$userid = $_POST['userid'];
$title = $_POST['title'];
$content = $_POST['content'];
$path= "/testBBS/";
$filename = date("YmdHis").".jpg";

$item = $marshaler->marshalJson('
    {
        "userid": "' . $userid . '",
        "title": "' . $title . '",
	"content": "' .$content. '",
	"filename": "' .$filename. '"
    }
');

$params = [
    'TableName' => 'contest',
    'Item' => $item
];


try {
    $result = $dynamodb->putItem($params);

} catch (DynamoDbException $e) {
    echo "Unable to add item:\n";
    echo $e->getMessage() . "\n";
}

?>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>게시물 작성 예제 폼</title>
</head>
<body>
<table>
<tr>
        <td>아이디:</td>
        <td><?=$userid;?></td>
</tr>
<tr>
        <td>전송제목:</td>
        <td><?=$title;?></td>
</tr>
<tr>
        <td>전송내용:</td>
        <td><?=$content;?></td>
</tr>
<tr>
        <td>전송이미지</td>
        <td><img src="<?=$path.$filename;?>" /></td>
</tr>
</table>
<p><b>전송완료</b></p>
<p><a href='list.php'>목록가기</a></p>
</body>
</html>
